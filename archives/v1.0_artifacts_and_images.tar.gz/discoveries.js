// fetch discoveries.json and visualize
async function loadAndVisualize() {
    try {
        const response = await fetch('discoveries.json');
        const data = await response.json();

        // Sort data by sector_index for timeline/sequence
        data.sort((a, b) => a.sector_index - b.sector_index);

        // 1. Update Summary Stats
        const totalSectors = data.length;
        const hubsCount = data.filter(d => d.type.includes('High Gravity Hub')).length;
        const maxAsym = Math.max(...data.map(d => d.max_asymmetry)).toFixed(2);
        const avgDelta = (data.reduce((sum, d) => sum + d.delta, 0) / totalSectors).toFixed(4);

        document.getElementById('stat-sectors').textContent = totalSectors;
        document.getElementById('stat-hubs').textContent = hubsCount;
        document.getElementById('stat-max-asym').textContent = maxAsym;
        document.getElementById('stat-avg-delta').textContent = avgDelta;

        // Shared chart config
        Chart.defaults.color = '#8c9cb3';
        Chart.defaults.font.family = "'Share Tech Mono', monospace";
        
        const labels = data.map(d => `Sector ${d.sector_index}`);

        // 2. Delta (Δ) Chart
        const deltaValues = data.map(d => d.delta);
        const ctxDelta = document.getElementById('deltaChart').getContext('2d');
        new Chart(ctxDelta, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Delta (Δ) Value',
                    data: deltaValues,
                    borderColor: '#00ffff',
                    backgroundColor: 'rgba(0, 255, 255, 0.1)',
                    borderWidth: 2,
                    pointBackgroundColor: '#00ffff',
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `Δ = ${context.parsed.y.toFixed(4)}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        grid: { color: 'rgba(0, 255, 255, 0.1)' },
                        min: 1.12,
                        max: 1.14
                    },
                    x: {
                        grid: { color: 'rgba(0, 255, 255, 0.1)' },
                        ticks: { maxRotation: 45, minRotation: 45 }
                    }
                }
            }
        });

        // 3. Asymmetry Spikes Chart
        const asymValues = data.map(d => d.max_asymmetry);
        const ctxAsym = document.getElementById('asymmetryChart').getContext('2d');
        
        // Dynamic colors: Highlight Sector 15 in gold, others in magenta/cyan mix
        const backgroundColors = data.map(d => {
            if (d.sector_index === 15) return 'rgba(255, 215, 0, 0.8)'; // Neon Gold for Sector 15
            if (d.max_asymmetry > 100) return 'rgba(255, 0, 127, 0.6)'; // Neon Magenta for high spikes
            return 'rgba(0, 255, 255, 0.4)'; // Cyan for lower values
        });

        const borderColors = data.map(d => {
            if (d.sector_index === 15) return '#ffd700';
            if (d.max_asymmetry > 100) return '#ff007f';
            return '#00ffff';
        });

        new Chart(ctxAsym, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Max Asymmetry',
                    data: asymValues,
                    backgroundColor: backgroundColors,
                    borderColor: borderColors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `Asymmetry = ${context.parsed.y.toFixed(2)}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        grid: { color: 'rgba(255, 0, 127, 0.1)' },
                        beginAtZero: true
                    },
                    x: {
                        grid: { display: false },
                        ticks: { maxRotation: 45, minRotation: 45 }
                    }
                }
            }
        });

    } catch (err) {
        console.error('Error loading discoveries:', err);
    }
}

document.addEventListener('DOMContentLoaded', loadAndVisualize);
